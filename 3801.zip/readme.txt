Included in this zip file are the necessary images, stylesheets and javascript files for all of the projects in the book.

A seperate file containing these resources AND all source code from the book will be available in the next few days.

Also be sure to visit www.railsprojects.com to talk with other readers of the book, share solutions to the exercise problems and be alerted to any changes to these source files.

Thanks

Eldon Alameda
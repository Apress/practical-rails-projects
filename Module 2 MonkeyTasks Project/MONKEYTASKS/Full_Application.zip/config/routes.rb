ActionController::Routing::Routes.draw do |map|
  map.connect '', :controller => 'today'
  map.connect ':controller/service.wsdl', :action => 'wsdl'
  map.connect ':controller/:action/:id.:format'
  map.connect ':controller/:action/:id'
end

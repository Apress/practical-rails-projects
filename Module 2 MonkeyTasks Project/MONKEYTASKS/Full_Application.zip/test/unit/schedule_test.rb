require File.dirname(__FILE__) + '/../test_helper'

class ScheduleTest < Test::Unit::TestCase
  fixtures :schedules

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end

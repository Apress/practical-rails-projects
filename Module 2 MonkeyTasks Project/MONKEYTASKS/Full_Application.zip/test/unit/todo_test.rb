require File.dirname(__FILE__) + '/../test_helper'

class TodoTest < Test::Unit::TestCase
  fixtures :todos

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
